# FIXED

startup_mspm0c110x_ticlang.o: \
 C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/m0p/startup_system_files/ticlang/startup_mspm0c110x_ticlang.c \
 C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/msp.h \
 C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/DeviceFamily.h \
 C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/m0p/mspm0c110x.h \
 C:/TI/mspm0_sdk_2_08_00_03/source/third_party/CMSIS/Core/Include/core_cm0plus.h \
 C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_adc12.h \
 C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_crc.h \
 C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_dma.h \
 C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_flashctl.h \
 C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_gpio.h \
 C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_gptimer.h \
 C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_i2c.h \
 C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_iomux.h \
 C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_spi.h \
 C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_uart.h \
 C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_vref.h \
 C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_wuc.h \
 C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_wwdt.h \
 C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/m0p/hw_factoryregion.h \
 C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/m0p/hw_cpuss.h \
 C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/m0p/hw_debugss.h \
 C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/m0p/hw_sysctl.h \
 C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/m0p/sysctl/hw_sysctl_mspm0c110x.h
C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/msp.h:
C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/DeviceFamily.h:
C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/m0p/mspm0c110x.h:
C:/TI/mspm0_sdk_2_08_00_03/source/third_party/CMSIS/Core/Include/core_cm0plus.h:
C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_adc12.h:
C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_crc.h:
C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_dma.h:
C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_flashctl.h:
C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_gpio.h:
C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_gptimer.h:
C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_i2c.h:
C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_iomux.h:
C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_spi.h:
C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_uart.h:
C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_vref.h:
C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_wuc.h:
C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/hw_wwdt.h:
C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/m0p/hw_factoryregion.h:
C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/m0p/hw_cpuss.h:
C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/m0p/hw_debugss.h:
C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/m0p/hw_sysctl.h:
C:/TI/mspm0_sdk_2_08_00_03/source/ti/devices/msp/peripherals/m0p/sysctl/hw_sysctl_mspm0c110x.h:
